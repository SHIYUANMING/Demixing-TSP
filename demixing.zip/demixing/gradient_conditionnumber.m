clear all;
clc
% rng('default');rng(1);
warning off
addpath('./fun');
testnum =1;
size_set =[800];
size_len = length(size_set);
s = 2;
con_set = [1:3];
con_len = length(con_set);
allcost = zeros(size_len,con_len,testnum);
r=1;
params.verbosity =2;
params.tol = 1e-6;
params.maxiter = 500;
params.tolgradnorm = 1e-8;
params.stepsize = 0.5;
 
allcost1 = zeros(size_len,con_len,testnum);
allcost2 = zeros(size_len,con_len,testnum);
allcost3 = zeros(size_len,con_len,testnum);
allcost4 = zeros(size_len,con_len,testnum);
allcost5 = zeros(size_len,con_len,testnum);
 
 
info =cell(size_len,1);
for t=1:size_len
    m = size_set(t);
    n1 = 50;
    n2 = 50;
    for ks = 1:con_len
        con  = con_set(ks);
        Ksize = [n1,n2,s,m];
     for ki = 1:testnum
         [X,y,C,x,h,g,z,y1 ] = generate_model_conditionnumber( m,n1,n2,s,con );
         [A,B,FC,CK] = generate_decon_matrix(m,n1,n2,s,C);
%% initial 
        
        [ h0,x0,d,mu] = RGD_initial(Ksize,A,B,FC,y); 
        X0_re =cellfun(@(h,x)[h;x],h0,x0,'Uni',0);                
%%  Riemannian
        [Xout1, infos1]=Riemannian_fixedrank_GD(r, Ksize,X0_re, params, A, y,X,x,h,C,B);
        info{ks} = infos1;
        x1 = cellfun(@(x,y)x(1:n1,:)*x(n1+1:end,:)',Xout1,'Uni',0);
        allcost1(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y,'fro')^2,Xout1,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost1(t,ks,ki));
      end
     end
end
 
 
figure,
for j = 1:con_len
  iter1 = size(info{j}.cost,2);
  re1 = zeros(iter1,1);
     for  i = 1:iter1
      re1(i) = info{j}.rmse(i);
     end
  iter_1 = 1:iter1;
  semilogy(iter_1,re1(iter_1),'LineWidth',2);hold on
end
title('Condition number','Interpreter','latex')
legend('$\kappa =1$','$\kappa =2$','$\kappa =3$','Interpreter','latex');
xlabel('iteration','FontSize',14,'Interpreter','latex');
ylabel('RMSE','FontSize',14,'Interpreter','latex');
set(gca,'Fontsize',14,'Fontname', 'Times New Roman','GridLineStyle','--');
axis tight;
grid on
 
