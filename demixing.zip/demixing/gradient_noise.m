% clear all;
% clc
 rng('default');rng(1);%warning('off', 'manopt:getHessian:approx');
addpath('./fun');
testnum =10;
size_set =3000;
m_len = size(size_set,2);
s = 10;
snr_set_index =-4:0.5:0;
snr_set = 10.^(snr_set_index);
size_snr = size(snr_set,2);
r=1;
params.verbosity =2;
params.costtol = 1e-6;
params.maxiter = 500;
params.tolgradnorm = 1e-12;
params.stepsize = 0.1;
allcost1 = zeros(m_len,size_snr,testnum);

ks = 1;

parfor ki = 1:testnum
    for i=1:m_len
      for t=1:size_snr
         
        m = size_set(i);
        n1 = 50; n2 = 50;
        omega = randn(m,1)+1i*randn(m,1);
        snr = snr_set(t);
        Ksize = [n1,n2,s,m];
         [X,y,C,x,h,g,z,y1 ] = generate_model( m,n1,n2,s );
         y = y+snr*norm(y)*(omega/norm(omega))/sqrt(2);
         [A,B,FC] = generate_decon_matrix(m,n1,n2,s,C);
         
%% initialization
       [ hr,xr,d,mu] = RGD_initial(Ksize,A,B,FC,y);
       X0_re = cellfun(@(h,x)[h;x],hr,xr,'Uni',0);
%%  Riemannian
        [Xout1, infos1]=Riemannian_fixedrank_GD(r, Ksize,X0_re, params, A, y,X,x,h,C,B);
        x1 = cellfun(@(x,y)x(1:n1,:)*x(n1+1:end,:)',Xout1,'Uni',0);
        allcost1(i,t,ki)=sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y,'fro')^2,Xout1,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost1(i,t,ki));

      end
   end
end

test_rmse1 = mean(allcost1,3);
figure,plot(-mag2db(snr_set),mag2db(test_rmse1(1,:)),'-s','LineWidth',1.5,'MarkerSize',6),hold on
% legend('m=3000','m=5000','m=7000','m=9000','m=12000');
xlabel('snr','FontSize',14);
ylabel('Relative reconstruction error (dB)','FontSize',14);
axis tight;
