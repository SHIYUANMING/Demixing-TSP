function [A,B,FC,Ck]= generate_decon_matrix(m,n1,n2,K,C)
A = cell(K,1);
FC = cell(K,1);
F = dftmtx(m)/sqrt(m);
B = F(:,1:n2);
for k=1:K
    Ck = F*C{k};
    FC{k} = Ck;
    Ak=zeros(m,n1*n2);
    for ri=1:m
        tmp = Ck(ri,:)'*conj(B(ri,:));
        Ak(ri,:)=tmp(:)';
       
        
    end
    A{k} = Ak;
  
end
end
 

