function [ u,v,d,mu] = RGD_initial(Ksize,A,B,FC,y)
%RGD_INITIAL �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
m =Ksize(4);n1 =  Ksize(1); n2 = Ksize(2);
% A_iy = cellfun(@(X)B'*diag(y)*X,FC,'Uni',0);
A_iy = cellfun(@(A)reshape(A'*y,[n1,n2]),A,'Uni',0);
[h,d,x] =  cellfun(@(x)svds(x,1),A_iy,'Uni',0);


Bh =cellfun(@(y)max(max(abs(B*y)))^2,h,'Uni',0);
fra = cellfun(@(x,y)(m*x)/norm(y)^2,Bh,h,'Uni',0);
mu = max(cell2mat(fra));
v=cellfun(@(d,x)x*sqrt(d),d,x,'Uni',0);
% u =minz(d,h,B,mu,m);
u = cellfun(@(d,x)x*sqrt(d),d,h,'Uni',0);
end
function z1 = minz(d,h,B,mu,L)
z =cellfun(@(d,h)sqrt(d)*h,d,h,'Uni',0);
cons = cellfun(@(z,d)2*sqrt(d)*mu-sqrt(L)*max(abs(B*z)),z,d,'Uni',0);
index = cell2mat(cons)<0;
if index==0
    z1 = z;
else
    zm = cell2mat(z);
    scale  =  cellfun(@(z,d)sqrt(L)*max(abs(B*z))/(2*sqrt(d)*mu),z,d,'Uni',0);
    scalem = cell2mat(scale);
    zm(index) = zm(index)./scalem(index);
    z1 = mat2cell(zm);
 end

end


