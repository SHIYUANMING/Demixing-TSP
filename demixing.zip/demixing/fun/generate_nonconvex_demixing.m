function [ X,y,C,x,h,A,B,FC ] = generate_nonconvex_demixing( m,n1,n2,K )
C = cell(K,1);
x = cell(K,1);
h = cell(K,1);
g = cell(K,1);
z = cell(K,1);
X = cell(K,1);
y = zeros(m,1);
F = dftmtx(m)/sqrt(m);
A = cell(K,1);
FC = cell(K,1);
B = F(:,1:n2);

for k=1:K
    h{k} = (randn(n2,1)+1i*randn(n2,1))/sqrt(2*n2);
    h{k} = h{k}/norm(h{k});
    g{k} = [h{k};zeros(m-n2,1)];
    a =(randn(m,n1)+1i*randn(m,n1))/sqrt(2);
  
    C{k} = a;
    x{k} =(randn(n1,1)+1i*randn(n1,1))/sqrt(2*n1);
    x{k} = x{k}/norm(x{k});
    z{k} = C{k}*x{k};
    X{k} = x{k}*conj(h{k}'); 
    Ck = C{k};  
    FC{k} = Ck;
    Ak=zeros(m,n1*n2);
   
    for ri=1:m
        tmp = Ck(ri,:)'*conj(B(ri,:));
        Ak(ri,:)=tmp(:)';    
    end
    A{k} = Ak;
    xx = X{k};
    y = y+Ak*xx(:);   
  
end

end

