function [ X,y,C,x,h,g,z,y1 ] = generate_model( m,n1,n2,K )
C = cell(K,1);
x = cell(K,1);
h = cell(K,1);
g = cell(K,1);
z = cell(K,1);
X = cell(K,1);
y1 = cell(K,1);
y = zeros(m,1);
F = dftmtx(m)/sqrt(m);
for k=1:K
    h{k} = (randn(n2,1)+1i*randn(n2,1))/sqrt(2*n2);
    h{k} = h{k}/norm(h{k});
    g{k} = [h{k};zeros(m-n2,1)];
    a =(randn(m,n1)+1i*randn(m,n1))/sqrt(2);
%     a1 =  randn(m,1)+1i*randn(m,1);
%     a(:,1) =(a1./abs(a1)).* abs(a(:,1));
    C{k} = a;
    x{k} =(randn(n1,1)+1i*randn(n1,1))/sqrt(2*n1);
    x{k} = x{k}/norm(x{k});

    z{k} = C{k}*x{k};
    X{k} = x{k}*conj(h{k}');
  
    y1{k} = cconv(z{k},g{k},m);
    y = y+F*y1{k}/sqrt(m);   
end

end

