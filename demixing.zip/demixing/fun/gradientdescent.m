function [x, cost,options,info] = gradientdescent(problem, x, options,X_or,C,B)

% A is the original matrix
if ~canGetCost(problem)
    warning('manopt:getCost', ...
        'No cost provided. The algorithm will likely abort.');
end
if ~canGetGradient(problem)
    warning('manopt:getGradient', ...
        'No gradient provided. The algorithm will likely abort.');
end

% Set local defaults here
localdefaults.minstepsize = 1e-10;
localdefaults.maxiter = 1000;
localdefaults.tolgradnorm = 1e-6;
localdefaults.storedepth = 20;
if ~canGetLinesearch(problem)
    localdefaults.linesearch = @linesearch_adaptive;
else
    localdefaults.linesearch = @linesearch_hint;
end

% Merge global and local defaults, then merge w/ user options, if any.
localdefaults = mergeOptions(getGlobalDefaults(), localdefaults);
if ~exist('options', 'var') || isempty(options)
    options = struct();
end
options = mergeOptions(localdefaults, options);
stepsize =options.stepsize;
n1 = size(X_or{1},1);
m = size(B,1);
s_user = size(X_or,1);
% For convenience
lincomb = problem.M.lincomb;


% If no initial point x is given by the user, generate one at random.
if ~exist('x', 'var') || isempty(x)
    x = problem.M.rand();
end

% Compute cost-related quantities for x
[cost, grad] = getCostGrad(problem,  x);
gradnorm = problem.M.norm(x, grad);


% Iteration counter (at any point, iter is the number of fully executed
% iterations so far)
iter = 0;
[u0,s0,v0] = cellfun(@(x)svds(x,1),X_or,'Uni',0);
x_o = cellfun(@(x,y)x*sqrt(y),u0,s0,'Uni',0);
h_o = cellfun(@(x,y)x*sqrt(y),v0,s0,'Uni',0);
[u,s,v] = cellfun(@(x)svds(x(1:n1,:)*x(n1+1:end,:)',1),x,'Uni',0);
x_e = cellfun(@(x,y)x*sqrt(y),u,s,'Uni',0);
h_e = cellfun(@(x,y)x*sqrt(y),v,s,'Uni',0);

norm_u =cellfun(@(x,y,s)norm(x*sqrt(s)-y),u,x_o,s,'Uni',0);

% Save stats in a struct array info and preallocate.
%stats = savestats();
info  = struct();
info.cost(1) = cost;
info.norm_u(1) = norm_u{1};
info.cohx(1) =max(cell2mat(cellfun(@(a,u,s,y)max(abs(a*(u*sqrt(s)-y)))*((sqrt(log(m)))^3)/norm(y),C,u,s,x_o,'Uni',0)));
info.cohh(1) =max(cell2mat(cellfun(@(v,s,y)max(abs(B*(v*sqrt(s))))*sqrt(m)/(log(m)^2),v,s,x_o,'Uni',0)));
info.rmse(1) =sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y,'fro')^2,x,X_or))/sum(cellfun(@(x,y)norm(x,'fro')^2,X_or)));
if options.verbosity >= 2
    fprintf(' iter\t               cost val\t    grad. norm\n');
end


% Start iterating until stopping criterion triggers
while true
    
      
    % Display iteration information
    if options.verbosity >= 2
       fprintf('%5d\t%+.16e\t%.8e\n', iter, cost, gradnorm);
    end
    
    
    % The line search algorithms require the directional derivative of the
    % cost at the current point x along the search direction.
    desc_dir = lincomb(x, -1, grad);
    normx = problem.M.norm(x,x)^2/2;
    newx = problem.M.retr(x, desc_dir,stepsize/normx);

     if iter >=options.maxiter || gradnorm <options.tol
         break
     end
    
    

    % Compute the new cost-related quantities for newx
    [newcost, newgrad] = getCostGrad(problem, newx);
    newgradnorm = problem.M.norm(newx, newgrad);
 
    % Transfer iterate info
    x = newx;
    cost = newcost;
    grad = newgrad;
    gradnorm = newgradnorm;

    [u,s,v] = cellfun(@(x)svds(x(1:n1,:)*x(n1+1:end,:)',1),x,'Uni',0);
    x_e = cellfun(@(x,y)x*sqrt(y),u,s,'Uni',0);
    h_e = cellfun(@(x,y)x*sqrt(y),v,s,'Uni',0);

    norm_u=  cellfun(@(x,y,s)norm(x*sqrt(s)-y),u,x_o,s,'Uni',0);


    % iter is the number of iterations we have accomplished.
    iter = iter + 1;
    info.cost(iter + 1) = cost;
    info.norm_u(iter+1) = norm_u{1};
    info.cohx(iter+1) =max(cell2mat(cellfun(@(a,u,s,y)max(abs(a*(u*sqrt(s)-y)))*((sqrt(log(m)))^3*norm(y)),C,u,s,x_o,'Uni',0)));
    info.cohh(iter+1) =max(cell2mat(cellfun(@(v,s,y)max(abs(B*(v*sqrt(s))))*sqrt(m)/(log(m)^2),v,s,x_o,'Uni',0)));
    info.rmse(iter+1) =sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y,'fro')^2,x,X_or))/sum(cellfun(@(x,y)norm(x,'fro')^2,X_or)));

end
end

