function [Xcg, infos]=Riemannian_fixedrank_GD(r, Ksize, X0, options, A, b,X_or,x_or,h_or,C,B)
if ~isfield(options,'tolgradnorm'); options.gradtol=1e-6; end
if ~isfield(options,'verbosity'); options.verbosity=1; end
m=Ksize(1); n=Ksize(2); K = Ksize(3);
% Pick the manifold of euclideancomplexfactory
problem.M = powermanifold(euclideancomplexfactory(m+n,r), K);
    %% Define the problem cost function 
    problem.cost = @cost;  
    function [f, store] = cost(X, store)
        if ~isfield(store,'Xmat')
            store.Xmat = cellfun(@(x)x(1:m,:)*x(m+1:end,:)',X,'Uni',0);
             
        end
        Ax = cellfun(@(x,y)x*y(:),A,store.Xmat,'Uni',0);
        f = norm(sum([Ax{:}],2)-b)^2;
    end

    %% Define the Euclidean gradient of the cost function 
    problem.egrad = @egrad;
    function [g,store] = egrad(X,store)
        % Same comment here about Xmat.
        if ~isfield(store,'Xmat')
            store.Xmat = cellfun(@(x)x(1:m,:)*x(m+1:end,:)',X,'Uni',0);
        end
        if ~isfield(store,'G')
            Ax = cellfun(@(x,y)x*y(:),A,store.Xmat,'Uni',0);
            store.G = cellfun(@(A)2*reshape(A'*(sum([Ax{:}],2)-b),[m,n]),A,'Uni',0);
        end
    g = cellfun(@(G,X)[G*X(m+1:end,:);G'*X(1:m,:)],store.G,X,'Uni',0);
    end

%% Define the Euclidean Hess  
problem.ehess = @ehess;
 function [Hess,store] = ehess(X, eta, store)
        if ~isfield(store,'Xmat')
            store.Xmat = cellfun(@(x)x(1:m,:)*x(m+1:end,:)',X,'Uni',0);
        end
        if ~isfield(store,'G')
            Ax = cellfun(@(x,y)x*y(:),A,store.Xmat,'Uni',0);
            store.G = cellfun(@(A)2*reshape(A'*(sum([Ax{:}],2)-b),[m,n]),A,'Uni',0);
        end
        
        Xmatdot = cellfun(@(x,y)y(1:m,:)*x(m+1:end,:)' + x(1:m,:)*y(m+1:end,:)',X,eta,'Uni',0);
        Axdot = cellfun(@(x,y)x*y(:),A,Xmatdot,'Uni',0);
        Pdot = cellfun(@(A)2*reshape(A'*(sum([Axdot{:}],2)),[m,n]),A,'Uni',0);
        
       
        HessL = cellfun(@(G,eta,Pdot,X)G * eta(m+1:end,:) + Pdot*X(m+1:end,:),store.G,eta,Pdot,X,'Uni',0);
        HessR = cellfun(@(G,eta,Pdot,X)G' * eta(1:m,:) + Pdot'*X(1:m,:),store.G,eta,Pdot,X,'Uni',0);
        Hess = cellfun(@(L,R)[L;R],HessL,HessR,'Uni',0);
       

 end
%  figure,checkgradient(problem);
%  figure,checkhessian(problem);
   
    %% 
       if ~isempty(X0)
           Xs = X0;
       else
           Xs = [];
       end
[Xcg, xcost, options,infos] = gradientdescent(problem, Xs, options,X_or,C,B);
end

