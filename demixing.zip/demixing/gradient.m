%  clear all;
% close all
clc
% rng('default');rng(1);
warning off
addpath('./fun');
testnum =1;
size_set =10;
size_len = length(size_set);
user_set = 10;
user_len = length(user_set);
allcost = zeros(size_len,user_len,testnum);
r=1;
params.verbosity =2;
params.tol = 1e-15;
params.maxiter = 200;
params.tolgradnorm = 1e-8;
params.stepsize = 0.1;

allcost1 = zeros(size_len,user_len,testnum);


info =cell(size_len,1);
for t=1:size_len
    n1 = size_set(t);
    n2 = size_set(t);
    m = 50*n1;
    for ks = 1:user_len
        s = user_set(ks);
        Ksize = [n1,n2,s,m];
     for ki = 1:testnum
         [X,y,C,x,h,A,B,FC] = generate_nonconvex_demixing( m,n1,n2,s );
%% initial 
        
        [ h0,x0,d,mu] = RGD_initial(Ksize,A,B,FC,y); 
        X0_re =cellfun(@(h,x)[h;x],h0,x0,'Uni',0);        
%%  Riemannian
        [Xout1, infos1]=Riemannian_fixedrank_GD(r, Ksize,X0_re, params, A, y,X,x,h,C,B);
        info{t} = infos1;
        x1 = cellfun(@(x,y)x(1:n1,:)*x(n1+1:end,:)',Xout1,'Uni',0);
        allcost1(t,ks,ki)=sqrt(sum(cellfun(@(x,y)norm(x(1:n1,:)*x(n1+1:end,:)'-y,'fro')^2,Xout1,X))/sum(cellfun(@(x,y)norm(x,'fro')^2,X)));
        fprintf('m:%.3d, K:%.2d, test:%.3d, cost:%.4e\n',m,s, ki,allcost1(t,ks,ki));
      end
     end
end

%%

figure,
for j = 1:size_len
  iter1 = size([info{j}.cost],2);
  re1 = zeros(iter1,1);
  rmse = [info{j}.rmse];
     for  i = 1:iter1
     re1(i) = rmse(i);
     end
     iter_1 = 1:iter1;
     semilogy(iter_1,re1(iter_1),'LineWidth',2);hold on
end
title('s = 10, m = 50K, $$\eta = 0.1$$','Interpreter','latex')
legend('K=10');
xlabel('Iteration count','FontSize',14,'Interpreter','latex');
ylabel('Relative error','FontSize',14,'Interpreter','latex');
set(gca,'Fontsize',14,'Fontname', 'Times New Roman','GridLineStyle','--');
axis tight;
grid on


%%
figure,
for j = 1:size_len
  iter1 = size(info{j}.cost,2);
  coh = zeros(iter1,1);
     for  i = 1:iter1
      coh(i) = info{j}.cohx(i);
     end
     iter_1 = 1:iter1;
     plot(iter_1,coh(iter_1),'LineWidth',2);hold on
end

title('s = 10, m = 50K, $$\eta = 0.1$$','Interpreter','latex')
legend('K=10');
ylabel('Incoherence','FontSize',14,'Interpreter','latex');
set(gca,'Fontsize',14,'Fontname', 'Times New Roman','GridLineStyle','--');
axis tight;
grid on


figure,
for j = 1:size_len
  iter1 = size(info{j}.cost,2);
  coh = zeros(iter1,1);
     for  i = 1:iter1
     coh(i) = info{j}.cohh(i);
     end
     iter_1 = 1:iter1;
      plot(iter_1,coh(iter_1),'LineWidth',2);hold on
end
title('s = 10, m = 50K, $$\eta = 0.1$$','Interpreter','latex')
legend('K=10');
xlabel('Incoherence','FontSize',14,'Interpreter','latex');
ylabel('RMSE','FontSize',14,'Interpreter','latex');
set(gca,'Fontsize',14,'Fontname', 'Times New Roman','GridLineStyle','--');
axis tight;
grid on
